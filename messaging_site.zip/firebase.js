// Placeholder for Firebase config
